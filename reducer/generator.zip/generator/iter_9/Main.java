package src.cuts;

class Main {
  static public final Function1<Byte, Character> expanding(String fiercer) {
    final Function1<Byte, Character> silliness = (Byte groped) -> {
      final Boolean foreswear = true;
      final Character cuffs = 'm';
      Character nonliving = 'c';
      return ((foreswear) ?
        cuffs : 
         nonliving);
      
    };
    final Boolean alibi = true;
    final Rigmarole<Short, Double> hexes = (Rigmarole<Short, Double>) null;
      ((alibi) ?
  new Strong<Integer>(hexes) : 
   new Strong<Integer>((Rigmarole<Short, Double>) null)).track.stubbed((short)34);
    return silliness;
    
  }

  static public final Number gnus(Character majesty, short hillier) {
    final Double battens = -98.253;
    final Double bulges = battens;
    Main.bleaching();
    return Main.shlepped(bulges);
    
  }

  static public final Byte shlepped(Double eulogize) {
    Byte friar = ((false) ?
      (byte)-63 : 
       (byte)-69);
    friar = friar;
    return friar;
    
  }

  static public final void bleaching() {
    Bacall aphelion = (Bacall) null;
    Strong<? super Integer> hearkens = aphelion.antique.camcorder;
    final Rigmarole<Short, Double> crusading = (Rigmarole<Short, Double>) null;
    hearkens.track = new Strong<Integer>(crusading);
    
  }

  static public final Float lawn(Long luigi) {
    final Float scot = (float)57.523;
    return scot;
    
  }

  static public final int vicarious(Warps allover, short bumps) {
    final Womanlike matters = Main.weeper(null);
    final Warps parking = matters.taipei().slow;
    final Angels<Number> rene = ((Prevue) null).dictums;
    return Main.vicarious(parking, rene.chaired);
    
  }

  static public final Womanlike weeper(Function3<? super Character, ? super Warps, ? super Number, Double> carouser) {
    final Womanlike reluctant = (Womanlike) null;
    final Opting<? super Boolean> support = (Opting<Boolean>) null;
    Warps ghanian = new Warps((Character meekly) -> {
  String creators = "pepped";
  final Bacall paradox = (Bacall) null;
  final Backup<? super Boolean> pintos = new Backup<Boolean>(-100.821);
  new Parallels<Bacall, Bacall>(paradox, pintos).entryways = null;
  return creators;
  
});
    support.slow = ghanian;
    return reluctant;
    
  }

  static public final Warps fudging(float tykes) {
    final Warps agings = new Warps((Character chutes) -> {  return "measliest";});
    final Warps watcher = agings;
    Warps medicare = ((true) ?
      agings : 
       watcher);
    return medicare;
    
  }

  static float slavonic = (float)-41.798;

  static Warps petered = Main.fudging(Main.slavonic);

  static short stammer = (short)5;

  static final int snitch = Main.vicarious(Main.petered, Main.petered.agreed(Main.petered.agreed(Main.petered.agreed(Main.stammer))));
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



interface Rigmarole<S extends Short, Z extends Double> {
  public abstract void stubbed(S dooming) ;
}

class Strong<K extends Integer> implements Rigmarole<Short, Double> {
  public Rigmarole<Short, Double> track;

  public Strong(Rigmarole<Short, Double> track) {
    super();
    this.track = track;
  }

  public void stubbed(Short dooming) {
    Object x_0 = -45;
    
  }
}

final class Federico<Q extends Function0<? extends Byte>, O extends Q> implements Rigmarole<Short, Double> {
  public final Strong<? super Integer> camcorder;
  public final Q jettison;

  public Federico(Strong<? super Integer> camcorder,Q jettison) {
    super();
    this.camcorder = camcorder;
    this.jettison = jettison;
  }

  public void stubbed(Short dooming) {
    Object x_1 = (Federico<Function0<Byte>, Function0<Byte>>) null;
    
  }
}

abstract class Bacall implements Rigmarole<Short, Double> {
  public Federico<Function0<Byte>, Function0<Byte>> antique;
  public Byte preppiest;

  public Bacall(Federico<Function0<Byte>, Function0<Byte>> antique,Byte preppiest) {
    super();
    this.antique = antique;
    this.preppiest = preppiest;
  }

  public void stubbed(Short dooming) {
    final Double artefacts = -24.999;
    Object x_2 = artefacts;
    
  }
}

final class Warps implements Rigmarole<Short, Double> {
  public final Function1<? super Character, String> oscars;

  public Warps(Function1<? super Character, String> oscars) {
    super();
    this.oscars = oscars;
  }

  public void stubbed(Short dooming) {
    final Boolean mutes = true;
    final Backup<Boolean> misbehave = new Backup<Boolean>(-64.556);
    final Backup<Boolean> bitters = ((mutes) ?
      misbehave : 
       misbehave);
    bitters.hoofs();
Function0<Boolean> x_3 = () -> {
      final Boolean lorenzo = false;
      final Dignity cynically = (Dignity) null;
      Dignity demeanor = (Dignity) null;
      Function2<Dignity, Federico<Function0<Byte>, ? super Function0<Byte>>, Void> harriett = (balaton, balloon) -> {
        Long preclude = (long)-7;
        Main.lawn(preclude);
        return null;
      };
      harriett.apply((Dignity) null, null);
        return ((lorenzo) ?
  cynically : 
   demeanor).carol(null, null);
      
    };
    ;
  }

  public final short agreed(short foulest) {
    return (short)-80;
  }
}

interface Dignity extends Rigmarole<Short, Double> {
  public abstract Boolean carol(Function2<Long, ? super Dignity, Warps> failing, Function0<? extends Long> trouser) ;
}

class Backup<O extends Boolean> implements Dignity {
  public final double edgar;

  public Backup(double edgar) {
    super();
    this.edgar = edgar;
  }

  public final void hoofs() {
    Bacall austen = (Bacall) null;
    final Bacall bemuse = austen;
    Object x_4 = bemuse.antique;
    
  }

  public void stubbed(Short dooming) {
    O shark = (O) null;
    Object x_5 = shark;
    
  }

  public Boolean carol(Function2<Long, ? super Dignity, Warps> failing, Function0<? extends Long> trouser) {
    Function0<O> harrison = () -> {
      return (O) null;
    };
    Function2<O, O, Void> thrive = (subsides, subpoena) -> {
      final O munched = (O) null;
      Object x_6 = munched;
      return null;
    };
    thrive.apply((O) null, (O) null);
    return harrison.apply();
    
  }
}

abstract class Opting<I> implements Rigmarole<Short, Double> {
  public Warps slow;

  public Opting(Warps slow) {
    super();
    this.slow = slow;
  }

  public void stubbed(Short dooming) {
    Integer nimble = -86;
    Function1<? super Character, String> survey = (Character mugging) -> {
      final String lyceum = "cameron";
      return lyceum;
      
    };
    slow = new Warps(survey);
    Object x_7 = nimble;
    
  }
}

class Parallels<P, D extends P> implements Rigmarole<Short, Double> {
  public D entryways;
  public final Backup<? super Boolean> mooning;

  public Parallels(D entryways,Backup<? super Boolean> mooning) {
    super();
    this.entryways = entryways;
    this.mooning = mooning;
  }

  public final String mansfield(Character projects) {
    return "jumbles";
  }

  public void stubbed(Short dooming) {
    Object x_8 = (D) null;
    
  }
}

interface Womanlike extends Rigmarole<Short, Double> {
  public abstract Opting<Character> taipei() ;

  public abstract Float conduced(Float dandier, long itchiness) ;
}

class Angels<S> extends Bacall {
  public short chaired;
  public final S briskest;

  public Angels(short chaired,S briskest) {
    super(new Federico<Function0<Byte>, Function0<Byte>>(new Strong<Integer>((Rigmarole<Short, Double>) null), () -> { Byte humble = (byte)99; return humble; }), (byte)-2);
    this.chaired = chaired;
    this.briskest = briskest;
  }

  public final void stubbed(Short dooming) {
    Object x_9 = (S) null;
    
  }

  public Womanlike overdue() {
    final Womanlike stank = (Womanlike) null;
    return stank;
    
  }
}

abstract class Prevue extends Strong<Integer> {
  public final Angels<Number> dictums;

  public Prevue(Angels<Number> dictums) {
    super(new Parallels<Warps, Warps>(new Warps((Character keens) -> { String dynamic = "brow"; return dynamic; }), new Backup<Boolean>(-27.77)));
    this.dictums = dictums;
  }

  public final void stubbed(Short dooming) {
    final Function0<Byte> pointing = () -> {      return (byte)79;};
    final Function0<Byte> fisk = pointing;
    dictums.chaired = (short)-33;
    Object x_10 = new Federico<Function0<Byte>, Function0<Byte>>(new Strong<Integer>((Rigmarole<Short, Double>) null), fisk);
    
  }

  public Opting<? extends Double> overcome(Opting<? extends Double> bridgman) {
    final Opting<Double> apt = (Opting<Double>) null;
    return apt;
    
  }
}

class Dentistry extends Parallels<Dentistry, Dentistry> {
  public final Short helpline;
  public final Double roseann;

  public Dentistry(Short helpline,Double roseann) {
    super((Dentistry) null, new Backup<Boolean>(-72.836));
    this.helpline = helpline;
    this.roseann = roseann;
  }

  public final String jogs(Character guerrilla) {
    final String rivera = "turbulent";
    Prevue heaviest = (Prevue) null;
    short rapturous = (short)-11;
    heaviest.track = new Angels<Boolean>(rapturous, true);
    return rivera;
    
  }

  public final void stubbed(Short dooming) {
    final Double solos = 55.902;
    Object x_11 = solos;
    
  }
}

abstract class Honester extends Opting<Warps> {
  public Honester() {
    super(new Warps((Character dover) -> { return "sores";}));
}

  public final void stubbed(Short dooming) {
    final Long stings = (long)22;
    Object x_12 = stings;
    
  }
}