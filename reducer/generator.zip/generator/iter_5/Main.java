package src.balanced;

class Main {
  static final Byte corks = (byte)45;

  static Boolean uncoils = ((byte)-89 != Main.corks);

  static final Double coifed = 79.437;

  static final Double sulfur = ((Main.uncoils) ?
  Main.coifed : 
   -38.961);

  static public final Vainglory bechtel(long foreigner) {
    final Vainglory smart = (Vainglory) null;
    return smart;
    
  }

  static Boolean validated = (Main.bechtel((long)-35).occluding <= (long)78);

  static public final Double ruddy(Double rutan) {
    final Boolean heraldic = (true && false);
    Double physique = rutan;
    Tiers knuckling = (Tiers) null;
    return ((heraldic) ?
      physique : 
       knuckling.sigma);
    
  }

  static final Integer feed = (((true && true)) ?
  1 : 
   -48);

  static final Float[] cooler = (Float[]) new Object[]{(Float) null};

  static public final Object ignoble() {
    final Object gibson = Main.ignoble();
    Boolean pollster = false;
    Main.uncoils = pollster;
    return gibson;
    
  }

  static public final short panza(short rosins) {
    return rosins;
  }

  static public final float cerf() {
    float occupancy = ((Zanier<String, String, Double>) null).quilt;
    Long perishes = (long)-37;
    final Long sulky = (long)69;
    Main.talc(Main.fanatic(new Lowly<Auspices>(new Auspices(perishes), new Auspices(sulky))).verdure((Pursuit) null).occluding, -53);
    return occupancy;
    
  }

  static public final void talc(Integer negros, int swines) {
    final Peron<Byte, Function2<Byte, Byte, Byte>> seasonal = Main.oxford(true);
    final int sailings = -32;
    Main.votes(sailings);
    seasonal.guffawing();
    
  }

  static public final void disarm() {
    Object x_0 = (byte)34;
    
  }

  static public final Peron<Byte, Function2<Byte, Byte, Byte>> oxford(boolean enriched) {
    long auburn = (long)-3;
    boolean filipino = true;
    final Peron<Byte, Function2<Byte, Byte, Byte>> sale = new Peron<Byte, Function2<Byte, Byte, Byte>>(auburn, filipino);
    Main.validated = enriched;
    return new Jobbed<Vainglory, Long, Integer>(sale, new Object()).urine;
    
  }

  static public final void votes(int tittering) {
    Ceylon<Long> effulgent = (Ceylon<Long>) null;
    final Punned<Integer> gnarlier = effulgent.diana.tingle();
    Long macro = gnarlier.nonuser(null, -73);
      ((false) ?
  new Synagogue<Function3<String, Boolean, Boolean, Vainglory>>((float)-89.100, new Lowly<Ceylon<Long>>((Ceylon<Long>) null, (Ceylon<Long>) null)::undiluted) : 
   new Synagogue<Function3<String, Boolean, Boolean, Vainglory>>((float)-64.621, (String albino, Boolean modelled, Boolean daley) -> {
  boolean calls = true;
  Peron<String, Function2<String, String, String>> pecuniary = new Peron<String, Function2<String, String, String>>((long)55, calls);
  Auras<Tiers, Float, Zanier<String, String, Double>> troupers = (Auras<Tiers, Float, Zanier<String, String, Double>>) null;
  troupers.unite();
  return pecuniary;
  
})).redoing((String whitener, Boolean linkage, Boolean dickey) -> {
  final long wimpier = (long)31;
  boolean eloquence = true;
  Pursuit clipt = (Pursuit) null;
  clipt.jingling();
  return new Peron<Float, Function2<Float, Float, Float>>(wimpier, eloquence);
  
}, (String programer, Boolean renounces, Boolean duvet) -> {
  Ceylon<Long> pralines = (Ceylon<Long>) null;
  Function1<Punned<? super Integer>, Void> warble = (douro) -> {
    float mysteries = (float)18.346;
    final Long trial = (long)-48;
    Tiers menkar = (Tiers) null;
    new Clubbed(trial, menkar).freewheel(null);
    Object x_2 = mysteries;
    return null;
  };
  warble.apply(null);
  return pralines;
  
});
    Object x_3 = macro;
    
  }

  static public final void type(int hindustan) {
    Object x_7 = (Number) new Long(22);
    
  }

  static public final Auspices fanatic(Patty acids) {
    final Long disarmed = (long)-10;
    return new Auspices(disarmed);
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Vainglory {
  public Integer occluding;

  public Vainglory(Integer occluding) {
    this.occluding = occluding;
  }

  public abstract Character kennan() ;

  public Double fondant(Function3<Float, Integer, Object, ? extends Double> burdock) {
    Double previewer = 26.21;
    return previewer;
    
  }
}

abstract class Tiers extends Vainglory {
  public Double sigma;
  public final short snitch;

  public Tiers(Double sigma,short snitch) {
    super(-36);
    this.sigma = sigma;
    this.snitch = snitch;
  }

  public Double fondant(Function3<Float, Integer, Object, ? extends Double> burdock) {
    final Double sepal = -89.552;
    return sepal;
    
  }

  public Character kennan() {
     return 'r';
  }
}

interface Patty {
  public abstract Function2<Character, Boolean, ? extends Byte> carlson(int monstrous, Vainglory aden) ;

  public abstract String honed(Function0<Character> yields) ;
}

abstract class Zanier<H extends String, G extends H, R extends Double> implements Patty {
  public float quilt;

  public Zanier(float quilt) {
    super();
    this.quilt = quilt;
  }

  public String honed(Function0<Character> yields) {
    final H whitman = (H) null;
    Main.validated = false;
    return whitman;
    
  }

  public Function2<Character, Boolean, ? extends Byte> carlson(int monstrous, Vainglory aden) {
return (Character fondness, Boolean cuckold) -> {      return (Byte) null;};
  }
}

final class Peron<A, I extends Function2<A, A, A>> extends Vainglory {
  public final long jocose;
  public boolean vainest;

  public Peron(long jocose,boolean vainest) {
    super(95);
    this.jocose = jocose;
    this.vainest = vainest;
  }

  public final int guffawing() {
    int bedsores = 50;
    return bedsores;
    
  }

  public Character kennan() {
    Character screams = 'J';
    Main.disarm();
    return screams;
    
  }
}

final class Jobbed<Y, F, Z> implements Patty {
  public final Peron<Byte, Function2<Byte, Byte, Byte>> urine;
  public final Object golf;

  public Jobbed(Peron<Byte, Function2<Byte, Byte, Byte>> urine,Object golf) {
    super();
    this.urine = urine;
    this.golf = golf;
  }

  public Function2<Character, Boolean, ? extends Byte> carlson(int monstrous, Vainglory aden) {
    long daiquiris = (long)-45;
    final Peron<Float, ? super Function2<Float, Float, Float>> tunneled = new Peron<Float, Function2<Float, Float, Float>>(daiquiris, true);
    Peron<Float, ? super Function2<Float, Float, Float>> listening = tunneled;
    Function2<Z, Y, Void> washed = (ramos, sharon) -> {
      final F boards = (F) null;
      F cocoas = boards;
      final Vainglory pikers = urine;
      pikers.occluding = 10;
      Object x_1 = cocoas;
      return null;
    };
    washed.apply((Z) null, (Y) null);
    return new Transom<Patty, Long, F>((short)19, listening)::mubarak;
    
  }

  public String honed(Function0<Character> yields) {
    String courier = "pouring";
    final Boolean aspect = false;
    Main.uncoils = aspect;
    return courier;
    
  }
}

class Transom<E extends Patty, T extends Long, Y> extends Tiers {
  public final short snitch;
  public final Peron<Float, ? super Function2<Float, Float, Float>> longhairs;

  public Transom(short snitch,Peron<Float, ? super Function2<Float, Float, Float>> longhairs) {
    super(91.849, (short)-81);
    this.snitch = snitch;
    this.longhairs = longhairs;
  }

  public Byte mubarak(Character psalter, Boolean redbreast) {
    Byte natty = (Byte) null;
    final Byte veldt = natty;
    return veldt;
    
  }
}

final class Punned<D extends Integer> extends Zanier<String, String, Double> {
  public Punned() {
    super((float)-0.601);
}

  public final Long nonuser(Jobbed<D, ? super D, D> saucers, D vaporize) {
    return (long)65;
  }
}

interface Cataloger extends Patty {
  public abstract Punned<Integer> tingle() ;
}

abstract class Ceylon<H extends Long> extends Transom<Patty, Long, Float> {
  public final Cataloger diana;
  public final H elision;

  public Ceylon(Cataloger diana,H elision) {
    super((short)45, new Peron<Float, Function2<Float, Float, Float>>((long)-16, false));
    this.diana = diana;
    this.elision = elision;
  }
}

class Synagogue<Q extends Function3<? super String, Boolean, ? super Boolean, ? extends Vainglory>> extends Vainglory {
  public Float rustled;
  public final Q wycliffe;

  public Synagogue(Float rustled,Q wycliffe) {
    super(-14);
    this.rustled = rustled;
    this.wycliffe = wycliffe;
  }

  public void redoing(Q negate, Q caledonia) {
    final double ginseng = 96.432;
    rustled = (float)61.194;
    Object x_4 = ginseng;
    
  }

  public Character kennan() {
    Character koontz = 'b';
    return koontz;
    
  }
}

class Lowly<O extends Ceylon<Long>> implements Cataloger {
  public final O heuristic;
  public final O grazed;

  public Lowly(O heuristic,O grazed) {
    super();
    this.heuristic = heuristic;
    this.grazed = grazed;
  }

  public Vainglory undiluted(String tersely, Boolean shelley, Boolean singulars) {
    long tickling = (long)73;
    final boolean townsend = true;
    Peron<Float, ? super Function2<Float, Float, Float>> pedagogic = new Peron<Float, Function2<Float, Float, Float>>(tickling, townsend);
    return new Transom<Patty, Long, String>((short)31, pedagogic);
    
  }

  public String honed(Function0<Character> yields) {
    return "titling";
  }

  public Function2<Character, Boolean, ? extends Byte> carlson(int monstrous, Vainglory aden) {
    final Function2<Character, Boolean, ? extends Byte> carnival = (Character tubercles, Boolean fares) -> {      return (Byte) null;};
    final Rubdown<Cataloger, Cataloger, Vainglory> citrus = new Rubdown<Cataloger, Cataloger, Vainglory>();
    citrus.tojo();
    return carnival;
    
  }

  public Punned<Integer> tingle() {
    Punned<Integer> tabloid = new Punned<Integer>();
    return tabloid;
    
  }
}

class Rubdown<E extends Cataloger, N extends E, Y> extends Synagogue<Function3<String, Boolean, Boolean, Vainglory>> {
  public Rubdown() {
    super((float)-51.926, (String besiegers, Boolean moleskin, Boolean whams) -> { Vainglory aptitude = new Synagogue<Function3<String, Boolean, Boolean, Vainglory>>(null, null); return aptitude; });
}

  public final void tojo() {
    N polaroids = (N) null;
    Object x_5 = polaroids;
    
  }
}

interface Auras<F extends Tiers, G extends Number, L extends Zanier<String, ? super String, ? super Double>> extends Cataloger {
  public abstract void unite() ;

  public abstract L cybele() ;
}

interface Pursuit extends Cataloger {
  public abstract void jingling() ;

  public abstract Jobbed<Integer, ? super Double, ? extends Number> sojourned() ;
}

final class Clubbed extends Ceylon<Long> {
  public final Long elision;
  public Tiers purifies;

  public Clubbed(Long elision,Tiers purifies) {
    super(new Lowly<Ceylon<Long>>((Ceylon<Long>) null, (Ceylon<Long>) null), (long)98);
    this.elision = elision;
    this.purifies = purifies;
  }

  public final void freewheel(Lowly<? super Clubbed> valencia) {
    byte racer = (byte)40;
    Object x_6 = racer;
    
  }

  public final Function2<Boolean, ? super Short, Integer> debut(Function1<Patty, Clubbed> snorkeled, int opened) {
    final Function2<Boolean, ? super Short, Integer> aligning = (Boolean herrick, Short notably) -> {
      final Integer roughage = -30;
      return roughage;
      
    };
    return aligning;
    
  }
}

final class Auspices extends Ceylon<Long> {
  public final Long elision;

  public Auspices(Long elision) {
    super((Pursuit) null, (long)-65);
    this.elision = elision;
  }

  public final Rubdown<? extends Cataloger, ? extends Cataloger, ? extends Short> verdure(Pursuit minerals) {
    Rubdown<? extends Cataloger, ? extends Cataloger, ? extends Short> germ = new Rubdown<Cataloger, Cataloger, Short>();
    final Rubdown<? extends Cataloger, ? extends Cataloger, ? extends Short> roughen = germ;
    int boulez = -47;
    Main.type(boulez);
    return roughen;
    
  }
}