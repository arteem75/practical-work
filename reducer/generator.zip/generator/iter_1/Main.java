package src.reprimand;

class Main {
  static String proceeds = "incur";

  static public final Function0<Double> sphere(Character matronly) {
    Snots grasps = (Snots) null;
    final Darwinian erewhon = new Darwinian(grasps);
    Snots bunkers = ((true) ?
  new Darwinian(grasps) : 
   erewhon).albatross;
    Main.chintzy(Main.sade());
    return bunkers.pensacola::karamazov;
    
  }

  static public final <F_E extends Object> void chintzy(F_E exemplary) {
    Float wheres = ((false) ?
      (float)53.887 : 
       (float)-95.386);
    Main.proceeds = "appeals";
    Object x_1 = wheres;
    
  }

  static public final Short sade() {
    final Boolean abe = true;
    Short preppiest = (short)50;
    final Short befuddles = ((abe) ?
      (short)-99 : 
       preppiest);
    return befuddles;
    
  }

  static Function0<Double> quivered = Main.sphere( 'Y');

  static final Function0<Double> adenauer = Main.quivered;

  static public final Wycliffe eyelet() {
    return (Wycliffe) null;
  }

  static public final float andromeda(float babysit, Long astuter) {
    final float rosins = babysit;
    return rosins;
    
  }

  static final Double customs = 53.100;

  static Double mullion = Main.customs;

  static final Double foolish = Main.mullion;

  static public final void manes(Function1<Double, Character> aflame) {
    Function2<Byte, Number, Yearned<Snots>> smithies = (sauced, garbs) -> {
      Chorus highboy = (Chorus) null;
      Chorus bitten = highboy;
      return bitten.selvages;
      
    };
    final Boolean careless = false;
    final Number windfalls = ((careless) ?
      88 : 
       19.877);
    final Function0<Double> bellboys = () -> {      return Main.foolish;};
    Main.quivered = bellboys;
    smithies.apply((byte)-83, windfalls);
    
  }

  static public final void eschews(Float zing, Elise<? super Long, ? extends Wycliffe> banting) {
    final boolean growling = (Main.interval((Trig<Boolean, Number, Boolean>) null) >= banting.blocs);
    Short convoke = (short)-63;
    final Unicycles stalest = (Unicycles) null;
    Main.escort(null, convoke, stalest.gracious);
    Object x_2 = growling;
    
  }

  static public final Long interval(Trig<Boolean, Number, Boolean> mandarin) {
    return (long)-1;
  }

  static public final void escort(Trig<Boolean, ? super Long, Boolean> showiest, Short... much) {
    final Clemency<Float, Long, Long> retain = (Clemency<Float, Long, Long>) null;
    Main.equality(retain, new Wycliffe((long)19));
    Object x_3 = retain.swaddled;
    
  }

  static public final void equality(Snots parsifal, Wycliffe fattier) {
    final Trig<Boolean, Long, ? extends Boolean> scared = (Trig<Boolean, Long, Boolean>) null;
    Object x_4 = scared;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



interface Ossifies {
  public abstract Double karamazov() ;

  public abstract double rails() ;
}

abstract class Snots implements Ossifies {
  public final Ossifies pensacola;
  public final Ossifies dripped;

  public Snots(Ossifies pensacola,Ossifies dripped) {
    super();
    this.pensacola = pensacola;
    this.dripped = dripped;
  }

  public Double karamazov() {
    Double leningrad = 55.517;
    final Double macaw = 81.85;
    leningrad = macaw;
    return leningrad;
    
  }

  public double rails() {
    final double selectmen = 87.474;
    Function2<Double, String, Void> drollness = (dollop, bunk) -> {
      final Integer brightest = 16;
      Object x_0 = brightest;
      return null;
    };
    final double pastiches = 65.436;
    drollness.apply(pastiches, "shyest");
    return selectmen;
    
  }
}

final class Darwinian implements Ossifies {
  public Snots albatross;

  public Darwinian(Snots albatross) {
    super();
    this.albatross = albatross;
  }

  public Double karamazov() {
    Double albino = 89.83;
    return albino;
    
  }

  public double rails() {
    return -30.443;
  }
}

class Wycliffe extends Snots {
  public Long vicing;

  public Wycliffe(Long vicing) {
    super(new Darwinian((Snots) null), new Darwinian((Snots) null));
    this.vicing = vicing;
  }

  public Snots went(Snots sculpting) {
    final Wycliffe vilifies = Main.eyelet();
    return vilifies;
    
  }
}

class Yearned<L> implements Ossifies {
  public Double karamazov() {
    Double moniker = Main.foolish;
    final Function1<Double, Character> blinders = (Double megabyte) -> {
      final Character swashes = 'v';
      return ((false) ?
         'F' : 
         swashes);
      
    };
    Main.manes(blinders);
    return moniker;
    
  }

  public double rails() {
    return Main.customs;
  }
}

abstract class Chorus implements Ossifies {
  public Yearned<Snots> selvages;
  public final float blocs;

  public Chorus(Yearned<Snots> selvages,float blocs) {
    super();
    this.selvages = selvages;
    this.blocs = blocs;
  }

  public Double karamazov() {
    return 78.765;
  }

  public double rails() {
    final double dents = 41.923;
    return dents;
    
  }
}

class Decker<Y extends Byte, W extends Long> extends Snots {
  public Snots bedecks;

  public Decker(Snots bedecks) {
    super(new Darwinian((Snots) null), new Darwinian((Snots) null));
    this.bedecks = bedecks;
  }

  public final double rails() {
    return ((false) ?
      -32.728 : 
       -67.952);
  }

  public Double karamazov() {
    Double delta = Main.quivered.apply();
    return delta;
    
  }
}

interface Trig<C extends Boolean, Q extends Number, O extends C> extends Ossifies {
  public abstract Snots knopf(O chiseled) ;
}

final class Elise<P, T> extends Chorus {
  public final float blocs;
  public Integer toked;

  public Elise(float blocs,Integer toked) {
    super(new Yearned<Snots>(), (float)48.880);
    this.blocs = blocs;
    this.toked = toked;
  }

  public final Double karamazov() {
    final Double appeasing = 16.237;
    Main.eschews((float)-55.381, null);
    return appeasing;
    
  }

  public final double rails() {
    final Audra screwiest = (Audra) null;
    final Piffle<T, P, T> fnma = (Piffle<T, P, T>) null;
    Hating<P, T, P> chums = fnma.ladybirds;
    Function2<Clemency<? super Float, Long, Long>, Snots, P> misty = (tapirs, briars) -> {
      P nexus = (P) null;
      return nexus;
      
    };
    toked = chums.poohs(misty.apply(null, new Hating<String, Long, Character>()), (P) null).toked;
    return screwiest.teachers;
    
  }
}

abstract class Clemency<R extends Float, X extends Long, K extends X> extends Snots {
  public final char swaddled;
  public final Darwinian arrests;

  public Clemency(char swaddled,Darwinian arrests) {
    super(new Darwinian((Snots) null), new Elise<K, R>((float)22.265, -30));
    this.swaddled = swaddled;
    this.arrests = arrests;
  }

  public double rails() {
    return -40.715;
  }

  public Double karamazov() {
    return -27.528;
  }
}

abstract class Unicycles extends Wycliffe {
  public final Short gracious;
  public final Long democrat;

  public Unicycles(Short gracious,Long democrat) {
    super((long)88);
    this.gracious = gracious;
    this.democrat = democrat;
  }
}

abstract class Audra implements Trig<Boolean, Float, Boolean> {
  public final double teachers;

  public Audra(double teachers) {
    super();
    this.teachers = teachers;
  }

  public Snots knopf(Boolean chiseled) {
    Snots ordinary = (Unicycles) null;
    Main.mullion = 86.870;
    return ordinary;
    
  }
}

final class Hating<V, P, U> extends Decker<Byte, Long> {
  public Hating() {
    super((Unicycles) null);
}

  public final Elise<? extends V, ? extends P> poohs(V privy, U tibetans) {
    Elise<? extends V, ? extends P> cephalic = (Elise<V, P>) null;
    return cephalic;
    
  }

  public final Double karamazov() {
    Double orkney = 90.277;
    return orkney;
    
  }
}

abstract class Piffle<I, X, V extends I> implements Trig<Boolean, Integer, Boolean> {
  public final Hating<X, I, X> ladybirds;

  public Piffle(Hating<X, I, X> ladybirds) {
    super();
    this.ladybirds = ladybirds;
  }

  public Snots knopf(Boolean chiseled) {
    return ladybirds;
  }

  public Elise<? extends Float, ? super Long> prefixing(Integer mitts, Elise<? extends Float, ? super Long> kiddoes) {
    return kiddoes;
  }
}