package src.flaunt;

class Main {
  static public final Double puppies(Function1<Byte, String> doughier, Short alchemy) {
    Double auspices = 40.291;
    return auspices;
    
  }

  static String recants = "orientals";

  static String bandied = "laurence";

  static final Double phalanx = (((Main.recants != Main.bandied)) ?
  -19.303 : 
   76.407);

  static public final Integer meekly(Integer fizziest, float aeolus) {
    Integer ronny = fizziest;
    final float snacks = (float)-80.997;
    final Integer maimed = Main.meekly(ronny, snacks);
    return maimed;
    
  }

  static public final <F_J extends Object> F_J stetson(F_J iblis) {
    final Maximum<F_J, F_J> wimps = (Maximum<F_J, F_J>) null;
    Maximum<F_J, F_J> feigned = wimps;
    Function1<Greg, Void> sledged = (ambushing) -> {
      Function2<F_J, F_J, Double[]> likes = (curative, clenching) -> {
        final Double[] revs = ((Cerf) null).shads;
        return revs;
        
      };
      Function1<F_J, F_J> plagued = (pittman) -> {
        final F_J apples = (F_J) null;
        return apples;
        
      };
      final Double[] sickness = likes.apply(plagued.apply((F_J) null), ((Asps<F_J>) null).adagios);
      Object x_0 = sickness;
      return null;
    };
    Asps<Boolean> finches = (Asps<Boolean>) null;
    sledged.apply(  ((true) ?
  finches : 
   new Teachers<Greg, Double, Boolean>()));
      return ((true) ?
  (Maximum<F_J, F_J>) null : 
   feigned).grady;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Greg {
  public Short harriett;

  public Greg(Short harriett) {
    this.harriett = harriett;
  }
}

class Teachers<Z extends Greg, N, C> extends Greg {
  public Teachers() {
    super((short)-90);
}
}

interface Addicting {
  public abstract Addicting petered(long pomposity) ;
}

abstract class Maximum<A extends Object, G> implements Addicting {
  public final A grady;

  public Maximum(A grady) {
    super();
    this.grady = grady;
  }

  public Greg doubloons(Greg numbering, char gael) {
    Greg knitters = new Horridly((Greg) null).rarefies;
    Boolean decimates = false;
    Greg wearily = knitters;
    knitters =   ((decimates) ?
  wearily : 
   (Greg) null);
    return knitters;
    
  }

  public abstract float burlier(Object fostered) ;
}

class Horridly extends Teachers<Greg, Float, Byte> {
  public final Greg rarefies;

  public Horridly(Greg rarefies) {
    super();
    this.rarefies = rarefies;
  }

  public Long toiletry() {
    final Long cosmoses = (long)-87;
    return cosmoses;
    
  }
}

abstract class Cerf extends Maximum<Integer, Integer> {
  public Double[] shads;
  public final Integer grady;

  public Cerf(Double[] shads,Integer grady) {
    super(-30);
    this.shads = shads;
    this.grady = grady;
  }

  public float burlier(Object fostered) {
    final float luella = (float)-22.627;
    Opine doggonest = new Opine((Cerf) null, "catholics");
    Double knuckling = -47.178;
    doggonest.tutorials(knuckling);
    return luella;
    
  }

  public Greg doubloons(Greg numbering, char gael) {
    Horridly dignity = new Horridly((Greg) null);
    Horridly toilets = dignity;
    shads = (Double[]) new Object[]{-24.822, -71.910, 38.402};
    return toilets;
    
  }
}

class Opine extends Teachers<Greg, Byte, Byte> {
  public Cerf blending;
  public final String gasworks;

  public Opine(Cerf blending,String gasworks) {
    super();
    this.blending = blending;
    this.gasworks = gasworks;
  }

  public void tutorials(Double attaching) {
    short ucayali = (short)87;
    Object x_1 = ucayali;
    
  }

  public final Float clones() {
    return (float)-80.203;
  }
}

abstract class Asps<A extends Object> extends Teachers<Greg, A, A> {
  public A adagios;

  public Asps(A adagios) {
    super();
    this.adagios = adagios;
  }

  public Double handfuls(Double connects) {
    Double babe = 21.513;
    return babe;
    
  }
}