package src.tudor;

class Main {
  static public final short teas() {
    return Main.teas();
  }

  static final short crusading = Main.teas();

  static final short civilly = Main.crusading;

  static public final Boolean forgery() {
    final Boolean noshed = false;
    return noshed;
    
  }

  static public final <F_R> void expending(F_R solely) {
    final F_R assizes = (F_R) null;
    Main.smug();
    Object x_4 = assizes;
    
  }

  static public final void smug() {
    Function0<Shinnied> x_5 = () -> {
      final Shinnied mitts = new Shinnied((float)-99.671);
      return mitts;
      
    };
    ;
  }

  static public final void hacksaws() {
    new Broke((long)-83).restates = null;
    Object x_7 = (Hookworm<Demising<Float, Number>>) null;
    
  }

  static public final Broke streak(short torches, Character stampedes) {
    short halyards = (short)-93;
    final short douched = (short)-64;
    return new Broke(Main.streak(  ((true) ?
  halyards : 
   douched), stampedes).tabasco);
    
  }

  static public final long growling() {
    long pounces = Main.growling();
    return pounces;
    
  }

  static Boolean coptic = Main.forgery();
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



class Hiatuses {
  public double wells;

  public Hiatuses(double wells) {
    this.wells = wells;
  }

  public final Integer meres(Integer attuning, Boolean soliloquy) {
    Integer stamped = attuning;
    double tossup = wells;
    wells = tossup;
    return stamped;
    
  }
}

interface Demising<E, K> {
  public abstract K confer(K sturgeons, short caching) ;
}

abstract class Klingon implements Demising<Byte, Boolean> {
  public final double poked;

  public Klingon(double poked) {
    super();
    this.poked = poked;
  }

  public short ululates() {
    final short aspen = (short)14;
    final short mailers = (short)89;
    Function1<Long, Void> gamer = (suite) -> {
      Byte racket = (byte)-71;
      final Shinnied choppier = new Shinnied((float)-51.698);
      final Float robs = choppier.sheratan;
      ((Killjoy<Float>) null).erosion(robs, robs);
      Object x_0 = racket;
      return null;
    };
    final Long fryers = (long)-69;
    gamer.apply(fryers);
    return ((false) ?
      aspen : 
       mailers);
    
  }

  public String emigrated(String excusable) {
    return excusable;
  }
}

interface Killjoy<D extends Float> extends Demising<Boolean, Long> {
  public abstract void erosion(D meteors, D indenture) ;

  public abstract D ives(D tweeting) ;
}

class Shinnied implements Killjoy<Float> {
  public final Float sheratan;

  public Shinnied(Float sheratan) {
    super();
    this.sheratan = sheratan;
  }

  public Long confer(Long sturgeons, short caching) {
    Long cleaver = (long)-50;
    Ailed bumblebee = (Ailed) null;
    Short taffies = (short)-40;
    bumblebee.careered(taffies, new Object());
    return cleaver;
    
  }

  public Float ives(Float tweeting) {
    final Float worker = (float)33.301;
    return worker;
    
  }

  public void erosion(Float meteors, Float indenture) {
    final Ailed alert = (Ailed) null;
    alert.wells = -54.307;
    Object x_1 = (long)46;
    
  }
}

abstract class Ailed extends Hiatuses {
  public Byte[] restates;

  public Ailed(Byte[] restates) {
    super(51.775);
    this.restates = restates;
  }

  public abstract void careered(Short catacombs, Object grabs) ;

  public abstract float fashioned(Function0<Ailed> sepals) ;
}

class Hookworm<E extends Demising<Float, ? extends Number>> extends Ailed {
  public Hookworm() {
    super((Byte[]) new Object[]{(Byte) null});
}

  public float fashioned(Function0<Ailed> sepals) {
    return (float)5.563;
  }

  public void careered(Short catacombs, Object grabs) {
    Main.hacksaws();
Function2<Shinnied, Double, Boolean> x_2 = (Shinnied weekends, Double blockhead) -> {
      final Boolean laws = Main.forgery();
      return laws;
      
    };
    ;
  }
}

class Broke extends Ailed {
  public final long tabasco;

  public Broke(long tabasco) {
    super((Byte[]) new Object[]{(Byte) null});
    this.tabasco = tabasco;
  }

  public final Boolean moment(Shinnied marcus, Double homegrown) {
    final Boolean decisive = false;
    Boolean shirked = false;
    Boolean hostelled = false;
    return ((decisive) ?
      shirked : 
       hostelled);
    
  }

  public float fashioned(Function0<Ailed> sepals) {
    float fiona = (float)48.555;
    Main.expending("curb");
    return fiona;
    
  }

  public void careered(Short catacombs, Object grabs) {
    final float coverts = ((true) ?
      (float)72.318 : 
       (float)-30.684);
    Thwacks<Klingon, Double, Double> cheetahs = new Thwacks<Klingon, Double, Double>(-77.637);
    Double desks = -59.527;
    cheetahs.graduated(desks, -68.642);
    Object x_3 = coverts;
    
  }
}

class Thwacks<S, Y, R extends Y> extends Klingon {
  public R funicular;

  public Thwacks(R funicular) {
    super(-45.59);
    this.funicular = funicular;
  }

  public void graduated(R heedful, R motleys) {
    final R drainers = (R) null;
    Object x_6 = drainers;
    
  }

  public Boolean confer(Boolean sturgeons, short caching) {
    return true;
  }
}