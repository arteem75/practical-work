package src.satyrs;

class Main {
  static Boolean longhairs = (15.192 != -59.37);

  static final Integer bakeries = 100;

  static Finns<Character, Float, Short> innocuous = (Finns<Character, Float, Short>) null;

  static final Integer scrip = ((Main.longhairs) ?
  Main.bakeries : 
   Main.innocuous.cultured);

  static char sheller = '8';

  static public final double watermark(double fastness) {
    return fastness;
  }

  static public final Number luxuriate(Function2<Short, ? super Character, Boolean> alligator) {
    Boolean godlike = Main.longhairs;
    Integer shyest = Main.bakeries;
    final Double thickets = -53.660;
    Function2<Double, Short[], Void> overlies = (logger, chainsaws) -> {
      final Double tussle = -32.68;
      Object x_1 = tussle;
      return null;
    };
    overlies.apply(thickets, (Short[]) new Object[]{  ((false) ?
  (Treadles) null : 
   (Treadles) null).cite, (short)93, Main.innocuous.dickey((short)39)});
    return ((godlike) ?
      shyest : 
       ((false) ?
        -58.55 : 
         thickets));
    
  }

  static public final byte weighty() {
    final byte tracing = (byte)15;
    return tracing;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Finns<U, S extends Object, G> {
  public final Integer cultured;
  public S instant;

  public Finns(Integer cultured,S instant) {
    this.cultured = cultured;
    this.instant = instant;
  }

  public U clerk(Finns<? extends G, ? extends S, ? extends S> cheetahs, S provable) {
    final U blog = (U) null;
    Function0<Void> acrylics = () -> {
      final S oculars = (S) null;
      S clavicle = oculars;
      Object x_0 = clavicle;
      return null;
    };
    acrylics.apply();
    return blog;
    
  }

  public abstract G dickey(G begetting) ;
}

abstract class Treadles extends Finns<Number, Double, Byte> {
  public final Short cite;
  public final Number employs;

  public Treadles(Short cite,Number employs) {
    super(37, 15.842);
    this.cite = cite;
    this.employs = employs;
  }

  public Byte dickey(Byte begetting) {
    Byte value = (byte)-100;
    return value;
    
  }

  public Number clerk(Finns<? extends Byte, ? extends Double, ? extends Double> cheetahs, Double provable) {
    return (long)92;
  }
}