package src.fomalhaut;

class Main {
  static public final Function3<? super Number, Short, Integer, String> partied(Short slow) {
    Boolean overgrew = ((true) ?
      false : 
       false);
    Ibex lubricate = (Ibex) null;
    Function3<Number, Short, Integer, String> remission = lubricate::timidly;
    return ((overgrew) ?
      ((false) ?
        remission : 
         lubricate::timidly) : 
       Main.partied((short)-30));
    
  }

  static public final Long wantons() {
    final Long thudding = ((Abusers) null).merck;
    return thudding;
    
  }

  static public final Abusers typewrite(byte crayola) {
    final Abusers grabs = (Abusers) null;
    grabs.merck = (long)37;
    return grabs;
    
  }

  static final byte sharkskin = (byte)-38;

  static final Abusers gino = Main.typewrite(Main.sharkskin);

  static Abusers flatware = Main.gino;

  static final Abusers sublime = ((false) ?
  Main.flatware : 
   new Lankiness<Boolean>((Abusers) null).watershed);

  static Short cayenne = (short)-54;

  static final short travelled = Main.cayenne;

  static public final char stagnant(char rodent) {
    char bitters = '9';
    return bitters;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Ibex {
  public abstract String timidly(Number nutshells, Short caliphs, Integer parcels) ;

  public abstract Function2<Long, Boolean, Character> slugging() ;
}

abstract class Abusers extends Ibex {
  public Long merck;
  public Double burped;

  public Abusers(Long merck,Double burped) {
    super();
    this.merck = merck;
    this.burped = burped;
  }

  public Function2<Long, Boolean, Character> slugging() {
    return ((true) ?
(Long namibia, Boolean shams) -> {         return '0';} : 
       new Senseless()::mojave);
  }

  public String timidly(Number nutshells, Short caliphs, Integer parcels) {
    Boolean listens = false;
    String climates = "taft";
    final String untenable = ((listens) ?
      climates : 
       "barrie");
    climates = untenable;
    return untenable;
    
  }
}

final class Senseless extends Ibex {
  public Senseless() {
    super();
}

  public final Character mojave(Long hardtack, Boolean plods) {
     return 'v';
  }

  public String timidly(Number nutshells, Short caliphs, Integer parcels) {
    return "unquoted";
  }

  public Function2<Long, Boolean, Character> slugging() {
    final Function2<Long, Boolean, Character> subsoil = this::mojave;
    return subsoil;
    
  }
}

class Lankiness<Z> extends Ibex {
  public final Abusers watershed;

  public Lankiness(Abusers watershed) {
    super();
    this.watershed = watershed;
  }

  public String timidly(Number nutshells, Short caliphs, Integer parcels) {
    return "lecture";
  }

  public Function2<Long, Boolean, Character> slugging() {
    Senseless subsists = new Senseless();
    Function2<Long, Boolean, Character> upswing = subsists::mojave;
    final Function2<Long, Boolean, Character> lathes = upswing;
    Function2<Integer, Character, Void> solidness = (flog, grimier) -> {
      final Z dinner = (Z) null;
      Object x_0 = dinner;
      return null;
    };
    solidness.apply(76,  'U');
    return lathes;
    
  }
}