package src.stomps;

class Main {
  static public final Number elsewhere(double tunneled, Function1<Wot, ? extends Short> lulling) {
    final Number comedown = (Number) null;
    Number sheepish = ((false) ?
      comedown : 
       (Number) null);
    sheepish = (Number) new Long(-47);
    return sheepish;
    
  }

  static Wot sunbeam = new Quoted<Object, Long, Long>((Number) new Long(-95));

  static Wot loathed = Main.sunbeam;
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Wot {
  public Number detesting(Number nursing) {
    return 81;
  }

  public abstract Function3<? super Byte, ? super Boolean, ? super Number, ? extends Number> frill(Function3<? super Byte, ? super Boolean, ? super Number, ? extends Number> erect) ;
}

class Quoted<Y, E, M> extends Wot {
  public final Number gimcrack;

  public Quoted(Number gimcrack) {
    super();
    this.gimcrack = gimcrack;
  }

  public Function3<? super Byte, ? super Boolean, ? super Number, ? extends Number> frill(Function3<? super Byte, ? super Boolean, ? super Number, ? extends Number> erect) {
    final Function3<? super Byte, ? super Boolean, ? super Number, ? extends Number> winded = (Byte bugaboo, Boolean wearable, Number soulful) -> {      return (Number) null;};
    Function2<M, Y, Y> motorway = (leland, tarp) -> {
      Y showily = (Y) null;
      Y sunniest = (Y) null;
      sunniest = (Y) null;
      return showily;
      
    };
    M clubs = (M) null;
    Y catharses = motorway.apply(clubs, (Y) null);
    Function1<String, Y> delibes = (marine) -> {
      final Y neuritis = (Y) null;
      M bedlams = (M) null;
      M flawed = bedlams;
      flawed = (M) null;
      return neuritis;
      
    };
    catharses = delibes.apply("addendums");
    return winded;
    
  }

  public final Number detesting(Number nursing) {
    Boolean intestate = true;
    Number echoed = ((intestate) ?
      -14.473 : 
       41.377);
    return echoed;
    
  }
}

class Trackers<T extends Object, S, H> extends Quoted<Boolean, Number, Integer> {
  public Object fomalhaut;

  public Trackers(Object fomalhaut) {
    super((Number) new Long(-49));
    this.fomalhaut = fomalhaut;
  }

  public Function3<? super Byte, ? super Boolean, ? super Number, ? extends Number> frill(Function3<? super Byte, ? super Boolean, ? super Number, ? extends Number> erect) {
return (Byte jangling, Boolean listless, Number frisian) -> {
      Warping gilds = (Warping) null;
      Number laws = Main.elsewhere(gilds.captivate, null);
      return laws;
      
    };
  }
}

abstract class Warping extends Quoted<Integer, Character, Wot> {
  public final double captivate;

  public Warping(double captivate) {
    super((Number) new Long(25));
    this.captivate = captivate;
  }

  public final Function3<? super Byte, ? super Boolean, ? super Number, ? extends Number> frill(Function3<? super Byte, ? super Boolean, ? super Number, ? extends Number> erect) {
return (Byte lithium, Boolean lolita, Number koizumi) -> {
      final Number smokiest = (Number) null;
      Function1<Quoted<? super Warping, ? extends Double, ? extends Long>, Void> shaves = (minatory) -> {
        Character whitaker = 'k';
        Object x_0 = whitaker;
        return null;
      };
      shaves.apply(null);
      return smokiest;
      
    };
  }

  public <F_H extends Boolean> F_H skis() {
    final F_H afrikaner = (F_H) null;
    return afrikaner;
    
  }
}

interface Template<O extends Object> {
  public abstract Number mulish(Byte fetuses, Boolean raiders, Number diffused) ;

  public abstract Function3<? super Long, ? super Character, ? super Byte, Short> sheller() ;
}

class Pickerel implements Template<Byte> {
  public Number mulish(Byte fetuses, Boolean raiders, Number diffused) {
    final Warping cupsful = new Gretzky<Trackers<Short, Disavow, Wot>, Boolean, Trackers<Short, Disavow, Wot>>( 'M').acquiring(null, true).rearming();
    Wot mable = new Gretzky<Trackers<Short, Disavow, Wot>, Byte, Trackers<Short, Disavow, Wot>>( 'J');
    Main.sunbeam = mable;
    return Main.elsewhere(cupsful.captivate, null);
    
  }

  public Function3<? super Long, ? super Character, ? super Byte, Short> sheller() {
    Boolean nervous = false;
    Snooping<Character> gags = (Snooping<Character>) null;
    Boolean select = true;
    nervous = select;
    return ((nervous) ?
      gags::deigned : 
 (Long salyut, Character upraise, Byte fishermen) -> {
        Short chorused = (short)-38;
        return chorused;
        
      });
    
  }
}

abstract class Disavow implements Template<Integer> {
  public Integer talon;
  public Function0<Integer> bacterium;

  public Disavow(Integer talon,Function0<Integer> bacterium) {
    super();
    this.talon = talon;
    this.bacterium = bacterium;
  }

  public Warping rearming() {
    Warping schindler = (Warping) null;
    final float dreary = (float)35.8;
    new Atoll(dreary, (Float dumfound) -> {  return (Byte) null;}).wishes();
    return schindler;
    
  }
}

class Atoll implements Template<Float> {
  public float terns;
  public Function1<Float, ? extends Byte> como;

  public Atoll(float terns,Function1<Float, ? extends Byte> como) {
    super();
    this.terns = terns;
    this.como = como;
  }

  public final void wishes() {
    Character sarasota = 'v';
    final Float strum = (float)-7.794;
    Pervaded<Warping, Float> earnhardt = new Pervaded<Warping, Float>(sarasota, strum);
    earnhardt.goners(-25.618);
    Object x_1 = "overbites";
    
  }

  public Number mulish(Byte fetuses, Boolean raiders, Number diffused) {
    return (Number) null;
  }

  public Function3<? super Long, ? super Character, ? super Byte, Short> sheller() {
    final Function3<Object, Object, ? super Byte, Short> handle = (Object ancestry, Object retouched, Byte guardian) -> {      return (short)50;};
    terns = (float)-51.297;
    return handle;
    
  }
}

final class Pervaded<Q extends Warping, Z> implements Template<Byte> {
  public Character innocent;
  public final Z mirages;

  public Pervaded(Character innocent,Z mirages) {
    super();
    this.innocent = innocent;
    this.mirages = mirages;
  }

  public final void goners(Double prow) {
    Z cattiest = (Z) null;
    Object x_2 = cattiest;
    
  }

  public Number mulish(Byte fetuses, Boolean raiders, Number diffused) {
    final Number trees = (Number) null;
    final Number sitting = trees;
    return sitting;
    
  }

  public Function3<? super Long, ? super Character, ? super Byte, Short> sheller() {
return (Long wallace, Object tautest, Number caulks) -> {
      Short comported = (short)51;
      return comported;
      
    };
  }
}

class Sellers extends Trackers<Double, Pickerel, Byte> {
  public Object argosies;
  public short unethical;

  public Sellers(Object argosies,short unethical) {
    super(new Object());
    this.argosies = argosies;
    this.unethical = unethical;
  }

  public final Short medicate(Long tuscany, Object fixation, Number jackpot) {
    return (short)64;
  }

  public final String plentiful(String quaintest, Float... huddles) {
    return "customs";
  }
}

final class Gretzky<P extends Trackers<Short, ? super Disavow, ? super Wot>, L extends Object, C extends P> extends Trackers<Integer, Disavow, Byte> {
  public Character conceited;

  public Gretzky(Character conceited) {
    super(new Object());
    this.conceited = conceited;
  }

  public final Disavow acquiring(Function2<C, C, ? extends P> hardier, Boolean trailways) {
    Disavow adjures = (Disavow) null;
    return adjures;
    
  }

  public final Function3<? super Byte, ? super Boolean, ? super Number, ? extends Number> frill(Function3<? super Byte, ? super Boolean, ? super Number, ? extends Number> erect) {
return (Byte jingoists, Boolean batty, Number pulsates) -> {      return (Number) null;};
  }
}

class Phonied<F> extends Warping {
  public Phonied() {
    super(4.422);
}

  public final Number pomposity(Byte months, Boolean eschews, Number relying) {
    Number reptilian = (Number) null;
    short logician = (short)-95;
    final Wot warhead = new Sellers(new Object(), logician);
    Main.sunbeam = warhead;
    return reptilian;
    
  }

  public final <F_H extends Boolean> F_H skis() {
    final F_H buncombe = (F_H) null;
    return buncombe;
    
  }
}

interface Snooping<G extends Character> extends Template<Character> {
  public abstract Short deigned(Number sputtered, Object decoding, Number kannada) ;
}

class Harped extends Wot {
  public Harped() {
    super();
}

  public Short calorific(Long seaway, Character provost, Byte admire) {
    return (short)71;
  }

  public Function3<? super Byte, ? super Boolean, ? super Number, ? extends Number> frill(Function3<? super Byte, ? super Boolean, ? super Number, ? extends Number> erect) {
    Function3<? super Byte, ? super Boolean, ? super Number, ? extends Number> truckled = erect;
    return truckled;
    
  }
}